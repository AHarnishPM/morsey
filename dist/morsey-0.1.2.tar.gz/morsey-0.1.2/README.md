# morsey
Contains methods to translate between morse code and english in both text and audio forms.

Uploaded as a package to PyPI. I'm currently implementing a method to read a .wav file and use an RNN model to extract morse code from it.

Runs on Python 3.9
