import morsey

print(morsey.morse_text_to_english_text("---"))

morsey.morse_text_to_audio("--- .. - .", 4, "test.wav", play=True)
